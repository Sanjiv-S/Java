

public class Helper {
    
    public static void printInstructions() {
        System.out.println("--------- Attendance Instructions ---------");
        System.out.println("Enter attendance for 7 days as 0 (Absent) or 1 (Present)");
}

}
